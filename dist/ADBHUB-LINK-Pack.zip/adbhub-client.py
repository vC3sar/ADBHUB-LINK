#!/usr/bin/env python3
"""
ADBHUB-LINK — Cliente Remoto ADB para Linux (Lubuntu / Ubuntu / Debian)
Modo AnyDesk Driverless: detecta el teléfono conectado por USB y puentea el puerto 5555 para el técnico.
Funciona 100% en consola/terminal pura o con interfaz gráfica Tkinter si existe entorno de escritorio.
"""

import os
import sys
import time
import subprocess
import threading
import socket
import random

LOCAL_FORWARD_PORT = 15555
PUBLIC_PORT = 5555

_last_forwarded_serial = None
_forward_lock = threading.Lock()

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def generate_anydesk_code():
    charset = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
    parts = ["".join(random.choices(charset, k=4)) for _ in range(4)]
    return "-".join(parts)

def get_connected_device():
    try:
        out = subprocess.check_output(["adb", "devices", "-l"], text=True, stderr=subprocess.DEVNULL)
        for line in out.strip().splitlines():
            line = line.strip()
            if not line or line.startswith("List of") or line.startswith("*"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                serial = parts[0]
                state = parts[1]
                model = "Dispositivo Android"
                for p in parts[2:]:
                    if p.startswith("model:"):
                        model = p.replace("model:", "").replace("_", " ")
                return serial, state, model
    except Exception:
        pass
    return None, None, None

def is_forward_active():
    """Verifica si el reenvío local hacia 127.0.0.1:15555 está activo y aceptando conexiones."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            return s.connect_ex(("127.0.0.1", LOCAL_FORWARD_PORT)) == 0
    except Exception:
        return False

def setup_adb_usb_forward(force=False):
    """Configura el puerto USB local para reenviar hacia el puerto ADB 5555 del teléfono."""
    global _last_forwarded_serial
    with _forward_lock:
        serial, state, model = get_connected_device()
        if not serial or state != "device":
            _last_forwarded_serial = None
            return False

        if is_forward_active() and serial == _last_forwarded_serial and not force:
            return True

        print(f"\n[ADB] Preparando enlace USB para {model} ({serial})...")

        # 1. Asegurar que adbd en el teléfono esté en modo tcpip 5555
        try:
            print("[ADB] Activando modo TCP/IP 5555 en el teléfono...")
            subprocess.run(["adb", "-s", serial, "tcpip", "5555"], capture_output=True, timeout=6)
            # Pausa para estabilización del daemon del teléfono
            time.sleep(1.5)
            subprocess.run(["adb", "-s", serial, "wait-for-device"], capture_output=True, timeout=6)
        except Exception as e:
            print(f"[!] Espera del teléfono: {e}")

        # 2. Limpiar cualquier forward anterior y reconfigurar
        try:
            subprocess.run(["adb", "-s", serial, "forward", "--remove", f"tcp:{LOCAL_FORWARD_PORT}"], capture_output=True)
            res = subprocess.run(
                ["adb", "-s", serial, "forward", f"tcp:{LOCAL_FORWARD_PORT}", "tcp:5555"],
                capture_output=True,
                text=True,
                timeout=6
            )
            if res.returncode != 0:
                print(f"[!] Error en adb forward: {res.stderr.strip()}")
                return False
        except Exception as e:
            print(f"[!] Error ejecutando adb forward: {e}")
            return False

        # 3. Comprobar que el reenvío esté efectivamente abierto y aceptando sockets
        time.sleep(0.4)
        if is_forward_active():
            _last_forwarded_serial = serial
            print(f"[OK] ✓ Túnel ADB USB verificado y listo en 127.0.0.1:{LOCAL_FORWARD_PORT}")
            return True
        else:
            print(f"[!] El puerto {LOCAL_FORWARD_PORT} no respondió a la comprobación de socket.")
            return False

def pipe_sockets(src, dst):
    try:
        while True:
            data = src.recv(4096)
            if not data:
                break
            dst.sendall(data)
    except Exception:
        pass
    finally:
        try: src.close()
        except Exception: pass
        try: dst.close()
        except Exception: pass

def start_tcp_bridge(listen_port=PUBLIC_PORT):
    """Escucha en 0.0.0.0:5555 y puentea los paquetes hacia el forward local del teléfono (127.0.0.1:15555)."""
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server.bind(("0.0.0.0", listen_port))
        server.listen(10)
        print(f"[OK] Servidor puente escuchando en 0.0.0.0:{listen_port}")
    except Exception as e:
        print(f"[!] No se pudo vincular al puerto {listen_port}: {e}")
        return

    while True:
        client_sock = None
        try:
            client_sock, addr = server.accept()
            print(f"\n[CONEXION] Petición entrante desde {addr[0]}:{addr[1]}")

            if not is_forward_active():
                print("[ADB] El enlace interno no estaba activo. Activando ahora...")
                if not setup_adb_usb_forward():
                    print("[!] No se pudo establecer el túnel USB. Rechazando petición.")
                    client_sock.close()
                    continue

            target_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            target_sock.settimeout(5.0)
            try:
                target_sock.connect(("127.0.0.1", LOCAL_FORWARD_PORT))
                target_sock.settimeout(None)
            except Exception as e:
                print(f"[!] No se pudo conectar a 127.0.0.1:{LOCAL_FORWARD_PORT} ({e}). Reintentando configuración...")
                if setup_adb_usb_forward(force=True):
                    try:
                        target_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        target_sock.connect(("127.0.0.1", LOCAL_FORWARD_PORT))
                    except Exception as e2:
                        print(f"[!] Segundo intento falló: {e2}")
                        client_sock.close()
                        continue
                else:
                    client_sock.close()
                    continue

            print(f"[OK] Enlace ADB establecido con éxito para {addr[0]}")
            t1 = threading.Thread(target=pipe_sockets, args=(client_sock, target_sock), daemon=True)
            t2 = threading.Thread(target=pipe_sockets, args=(target_sock, client_sock), daemon=True)
            t1.start()
            t2.start()
        except Exception as e:
            if client_sock:
                try: client_sock.close()
                except Exception: pass
            time.sleep(0.2)

def run_cli_client(code, local_ip):
    os.system("clear")
    print("========================================================================")
    print(" ⚡ ADBHUB-LINK — CLIENTE REMOTO ADB (LUBUNTU / LINUX)")
    print("========================================================================")
    print("\n  DIRECCIÓN DE CONEXIÓN PARA EL TÉCNICO:\n")
    print(f"      >>>  {local_ip}:5555  <<<   (o Código AnyDesk: {code})\n")
    print("========================================================================")
    print(f"  El técnico debe ingresar '{local_ip}:5555' en su panel de Windows.")
    print("  Mantenga esta consola abierta para permitir la comunicación remota.")
    print("========================================================================")

    last_serial = None
    last_state = None
    while True:
        serial, state, model = get_connected_device()
        if serial:
            if serial != last_serial or state != last_state:
                if state == "device":
                    if not is_forward_active():
                        setup_adb_usb_forward()
                last_serial = serial
                last_state = state

            if state == "device":
                print(f"\r[ESTADO] Conectado: {model} ({serial}) - ✓ AUTORIZADO (Túnel Listo en {local_ip}:5555)  ", end="", flush=True)
            elif state == "unauthorized":
                print(f"\r[ESTADO] ⚠ Teléfono detectado pero NO AUTORIZADO (Permitir depuración en pantalla)      ", end="", flush=True)
            else:
                print(f"\r[ESTADO] ⚠ Estado: {state.upper()} (Verifique conexión y modo depuración USB)         ", end="", flush=True)
        else:
            last_serial = None
            last_state = None
            print(f"\r[ESTADO] Esperando teléfono USB con Depuración USB activa...                             ", end="", flush=True)
        time.sleep(2)

def start_gui(code, local_ip):
    # Si no hay entorno gráfico $DISPLAY, pasar a modo consola pura directamente
    if not os.environ.get("DISPLAY"):
        run_cli_client(code, local_ip)
        return

    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.title("ADBHUB-LINK — Cliente Remoto ADB")
        root.geometry("560x440")
        root.configure(bg="#0f172a")

        header = tk.Label(root, text="⚡ ADBHUB-LINK", font=("Helvetica", 20, "bold"), fg="#38bdf8", bg="#0f172a")
        header.pack(pady=(15, 3))

        sub = tk.Label(root, text="ESTACIÓN DEL CLIENTE (LUBUNTU / LINUX)", font=("Helvetica", 10, "bold"), fg="#94a3b8", bg="#0f172a")
        sub.pack()

        card = tk.Frame(root, bg="#1e293b", padx=20, pady=15, relief="groove", bd=1)
        card.pack(fill="x", padx=30, pady=15)

        lbl = tk.Label(card, text="DIRECCIÓN DE CONEXIÓN PARA EL TÉCNICO", font=("Helvetica", 9), fg="#94a3b8", bg="#1e293b")
        lbl.pack()

        code_text = f"{local_ip}:5555"
        code_lbl = tk.Label(card, text=code_text, font=("Courier", 22, "bold"), fg="#4ade80", bg="#1e293b")
        code_lbl.pack(pady=6)

        sub_code = tk.Label(card, text=f"Código AnyDesk Alternativo: {code}", font=("Helvetica", 9), fg="#94a3b8", bg="#1e293b")
        sub_code.pack()

        def copy_code():
            root.clipboard_clear()
            root.clipboard_append(code_text)
            messagebox.showinfo("Copiado", f"Dirección {code_text} copiada al portapapeles.")

        btn = tk.Button(card, text="📋 Copiar Dirección", command=copy_code, bg="#3b82f6", fg="white", font=("Helvetica", 10, "bold"), padx=10, pady=4, relief="flat")
        btn.pack(pady=6)

        dev_card = tk.Frame(root, bg="#1e293b", padx=15, pady=15, relief="groove", bd=1)
        dev_card.pack(fill="x", padx=30, pady=(0, 15))

        dev_title = tk.Label(dev_card, text="TELÉFONO DETECTADO EN ESTE EQUIPO:", font=("Helvetica", 9), fg="#94a3b8", bg="#1e293b")
        dev_title.pack(anchor="w")

        dev_status = tk.Label(dev_card, text="Buscando teléfono conectado por USB...", font=("Helvetica", 11, "bold"), fg="white", bg="#1e293b")
        dev_status.pack(anchor="w", pady=4)

        last_seen = {"serial": None, "state": None}

        def update_device():
            serial, state, model = get_connected_device()
            if serial:
                if serial != last_seen["serial"] or state != last_seen["state"]:
                    if state == "device":
                        if not is_forward_active():
                            setup_adb_usb_forward()
                    last_seen["serial"] = serial
                    last_seen["state"] = state

                if state == "device":
                    dev_status.config(text=f"📱 {model} ({serial})\nEstado: ✓ AUTORIZADO (Túnel Listo en {local_ip}:5555)", fg="#4ade80")
                elif state == "unauthorized":
                    dev_status.config(text=f"📱 {model} ({serial})\nEstado: ⚠ NO AUTORIZADO (Permitir depuración en pantalla)", fg="#facc15")
                else:
                    dev_status.config(text=f"📱 {model} ({serial})\nEstado: ⚠ {state.upper()} (Verifique depuración USB)", fg="#facc15")
            else:
                last_seen["serial"] = None
                last_seen["state"] = None
                dev_status.config(text="📱 No se detecta ningún teléfono por USB.\nActive 'Depuración USB' en Ajustes de desarrollador.", fg="#ef4444")
            root.after(2000, update_device)

        update_device()
        root.mainloop()
    except Exception:
        run_cli_client(code, local_ip)

if __name__ == "__main__":
    local_ip = get_local_ip()
    code = generate_anydesk_code()

    # Iniciar el servidor puente TCP en segundo plano en el puerto público 5555
    t = threading.Thread(target=start_tcp_bridge, args=(PUBLIC_PORT,), daemon=True)
    t.start()

    start_gui(code, local_ip)
