#!/usr/bin/env bash
# ADBHUB-LINK — Lanzador del Cliente
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$HOME/adbhub"

if [ -f "$DIR/adbhub-client.py" ]; then
    python3 "$DIR/adbhub-client.py"
elif [ -f "$APP_DIR/adbhub-client.py" ]; then
    python3 "$APP_DIR/adbhub-client.py"
else
    echo "Descargando cliente..."
    curl -s http://192.168.1.86:8888/download/linux | bash
fi
