#!/usr/bin/env bash
# ADBHUB-LINK — Instalador y Lanzador Automatico para Lubuntu / Linux
set -e

echo "================================================================================"
echo " ⚡ ADBHUB-LINK — Instalando Cliente en Lubuntu / Linux"
echo "================================================================================"

# 1. Comprobar e instalar adb, udev rules y python3
if ! command -v adb >/dev/null 2>&1 || ! command -v python3 >/dev/null 2>&1; then
    echo ">>> Instalando herramientas necesarias (adb, python3, reglas udev)..."
    sudo apt-get update && sudo apt-get install -y adb android-sdk-platform-tools-common python3 python3-tk curl || sudo apt-get install -y adb python3 python3-tk curl
fi

# 2. Configurar permisos USB y puerto en firewall
sudo usermod -aG plugdev "$USER" 2>/dev/null || true
if command -v ufw >/dev/null 2>&1; then
    sudo ufw allow 5555/tcp >/dev/null 2>&1 || true
fi

# 3. Carpeta de trabajo dedicada
APP_DIR="$HOME/adbhub"
mkdir -p "$APP_DIR"
cd "$APP_DIR"

echo ">>> Descargando componentes del cliente ADBHUB-LINK..."
SERVER="http://192.168.1.86:8888"
curl -s -o "$APP_DIR/adbhub-client.py" "$SERVER/adbhub-client.py" || true
curl -s -o "$APP_DIR/iniciar-cliente.sh" "$SERVER/iniciar-cliente.sh" || true

# Asegurar permisos de ejecucion en la carpeta de la aplicacion
chmod +x "$APP_DIR"/*.sh "$APP_DIR"/*.py 2>/dev/null || true

# Copiar iniciar-cliente.sh a $HOME para que ./iniciar-cliente.sh funcione directamente
cp -f "$APP_DIR/iniciar-cliente.sh" "$HOME/iniciar-cliente.sh" 2>/dev/null || true
chmod +x "$HOME/iniciar-cliente.sh" 2>/dev/null || true

# Crear enlace simbolico global si es posible
if [ -w /usr/local/bin ]; then
    ln -sf "$APP_DIR/iniciar-cliente.sh" /usr/local/bin/adbhub 2>/dev/null || true
fi

# 4. Acceso directo en el Escritorio si existe
if [ -d "$HOME/Desktop" ]; then
    cat <<EOF > "$HOME/Desktop/ADBHUB-Cliente.desktop"
[Desktop Entry]
Type=Application
Name=ADBHUB-LINK Cliente
Exec=bash $HOME/adbhub/iniciar-cliente.sh
Icon=phone
Terminal=true
Categories=Utility;
EOF
    chmod +x "$HOME/Desktop/ADBHUB-Cliente.desktop" 2>/dev/null || true
fi

echo "================================================================================"
echo " [OK] Instalacion completada con exito."
echo " Para iniciar en cualquier momento:"
echo "   ./iniciar-cliente.sh"
echo "================================================================================"
echo " >>> Iniciando Cliente Remoto ADB..."
echo ""

exec python3 "$APP_DIR/adbhub-client.py"
